# Dino Breeding — addon de reprodução para Unusual Prehistory 1 e 2

Faz os dinossauros (e outros animais pré-históricos) do **Unusual Prehistory 1** e do
**Unusual Prehistory 2** se reproduzirem: dê a comida certa a dois adultos da mesma
espécie e nasce um filhote.

- Minecraft **1.20.1**, **Forge 47.x** (o mesmo que o UP2 já exige)
- Funciona com o UP1, com o UP2, ou com os dois juntos (cada um é opcional)
- Não mexe nos `.jar` dos mods originais. É um mod à parte
- Feito para: **UP1 1.5.0.3** e **UP2 1.20.1-1.4.3**

> ⚠️ **Este addon ainda não foi testado dentro do jogo.** Foi escrito a partir da leitura do
> código dos dois mods e só foi compilado contra stubs da API. Se algo falhar, mande o arquivo
> `logs/latest.log` (ou o relatório em `crash-reports/`) que eu corrijo.

---

## 0. No celular (MojoLauncher): gerar o `.jar` sem PC

O `.zip` é só o **código-fonte**. Renomear para `.jar` não funciona: o Forge precisa das
classes compiladas, e isso só o Gradle faz. No celular, o jeito mais simples é deixar o
**GitHub Actions** (grátis) compilar para você, pelo navegador:

1. Crie uma conta e um repositório novo no GitHub (se a página ficar estranha, ative
   "Site para computador" no navegador).
2. **Add file → Upload files** e envie este `.zip` **sem descompactar**. O repositório deve ter só um `.zip`.
3. **Add file → Create new file**. No nome, digite `.github/workflows/build.yml`
   e cole o conteúdo do arquivo `build-github.yml` (que está dentro deste zip). Confirme com **Commit**.
4. Aba **Actions**: aguarde o build terminar (uns 5 a 10 minutos na primeira vez).
5. Aba **Releases** (ou "Code → Releases"): baixe o `dinobreeding-1.0.0.jar` do build mais recente.
6. Coloque o `.jar` na pasta `mods` do seu perfil Forge no MojoLauncher, junto com o UP1 e o UP2.

Se o build falhar, abra a execução em **Actions**, copie o erro e mande para mim.

**Sem teclado, sem SHIFT:** no celular, o "SHIFT" é o botão de **agachar** na tela. Para
dinos hostis, ative o agachar (ele fica ligado) e então toque na comida em cima do dino.

Depois de entrar em um mundo, o `logs/latest.log` terá uma linha `[dinobreeding] N especies
registradas`, e outra listando o que não foi encontrado. Isso mostra rápido se os IDs batem com a sua versão dos mods.

---

## 1. Como gerar o `.jar` (no PC)

Precisa de **JDK 17** instalado e de internet (o Gradle baixa o Forge na primeira vez).

**Windows** (PowerShell ou Prompt, dentro desta pasta):

```
gradlew.bat build
```

**Linux / macOS:**

```
./gradlew build
```

A primeira execução demora vários minutos (baixa o Forge e prepara o Minecraft).
Quando terminar, o mod estará em:

```
build/libs/dinobreeding-1.0.0.jar
```

Se o wrapper der problema, alternativa: baixe o **Forge MDK 1.20.1 (47.3.0)** em
files.minecraftforge.net, extraia, apague a pasta `src` dele e copie a `src` desta pasta no lugar.

## 2. Instalação

Copie `dinobreeding-1.0.0.jar` para a pasta `mods` do Minecraft, junto com os `.jar` do UP1
e do UP2. Em servidor multiplayer, instale no servidor **e** nos clientes.

## 3. Como usar no jogo

1. Segure a **comida da espécie** e clique com o botão direito no dino (com a vida cheia).
   Aparecem corações. Se ele estiver ferido, a comida continua curando, como nos mods originais.
2. Faça o mesmo com **outro adulto da mesma espécie**, perto do primeiro (até 16 blocos).
3. Os dois se aproximam e nasce o filhote. Os pais ficam 5 minutos sem poder acasalar de novo.

**Dinos "amigáveis"** aceitam o clique normal: domesticados, pacificados (os que o mod
pacifica com comida) ou de espécies pacíficas. Em dinos **hostis/selvagens**, segure
**SHIFT** ao clicar. Isso evita atrapalhar o jeito original dos mods de pacificar e
domesticar com comida.

### Qual é a comida?

| Espécie | Comida de acasalamento |
|---|---|
| Todo o **UP2** | A comida original de cada espécie (a mesma que cura/pacifica, definida pelo próprio mod) |
| UP1: Triceratops | Fruto de ginkgo |
| UP1: Majungasaurus | Coty cru (`raw_coty`) |
| UP1: Pachycephalosaurus | Sementes de ginkgo cruas |
| UP1: Kentrosaurus | Horsetail |
| UP1: Barinasuchus, Hwachavenator | Meaty Buffet, além de carne e peixe |
| UP1: Ulughbegsaurus | Qualquer carne |
| UP1: Beelzebufo | A comida que o próprio mod já usa |
| UP1: carnívoros (Rex, Smilodon, Megalania, Velociraptor, Austroraptor...) | Carne (boi, porco, carneiro, frango, coelho) |
| UP1: herbívoros (Brachiosaurus, Mamute, Megatherium, Paraceratherium, Gigantopithecus, Coty, Antarctopelta, Talpanas) | Plantas (trigo, maçã, cenoura, folhas, bagas...) |
| UP1: aquáticos (Dunkleosteus, Palaeophis) | Peixe (e carne, no Palaeophis) |

As dietas de carne, peixe e plantas são **tags de itens** e podem ser editadas por datapack
(`data/dinobreeding/tags/items/food/meat.json`, `fish.json`, `plants.json`).

### Como nascem os filhotes

- **UP1, espécies com filhote próprio** (Rex, Brachiosaurus, Mamute, Smilodon, Megatherium,
  Megalania, Paraceratherium, Gigantopithecus, Barinasuchus, Palaeophis, Dunkleosteus e o
  girino do Beelzebufo): nasce a entidade de filhote do mod (Baby Rex etc.), que cresce
  pelo sistema do próprio UP1.
- **Todas as outras** (UP2 inteiro e o resto do UP1): nasce o próprio dino em versão bebê,
  como os animais do jogo padrão, e cresce com o tempo.
- A cor/variante de um dos pais é herdada. Se um dos pais for domesticado, o filhote nasce
  domesticado pelo mesmo dono (quando o tipo de filhote permite).

## 4. Espécies incluídas

- **UP1 (23):** Rex, Brachiosaurus, Mamute, Smilodon, Megatherium, Megalania, Paraceratherium,
  Gigantopithecus, Barinasuchus, Palaeophis, Dunkleosteus, Beelzebufo, Majungasaurus,
  Triceratops, Velociraptor, Pachycephalosaurus, Cotylorhynchus, Kentrosaurus, Antarctopelta,
  Hwachavenator, Austroraptor, Ulughbegsaurus, Talpanas.
- **UP2 (19):** Carnotaurus, Dromaeosaurus, Kentrosaurus, Majungasaurus, Megalania,
  Brachiosaurus, Kaprosuchus, Leptictidium, Lystrosaurus, Pachycephalosaurus, Praepusa,
  Ulughbegsaurus, Desmatosuchus, Psilopterus, Metriorhynchus, Mosasaurus, Aegirocassis,
  Dunkleosteus, Hibbertopterus.

**De fora, de propósito:**
- Talpanas e Unicorn do UP2, que já se reproduzem sozinhos.
- Peixes pequenos, insetos, animais voadores (Pterodactylus, Telecrex, Anurognathus),
  Eryon, Living Ooze, Grug e criaturas ambientais.
- Mamute, Therizinosaurus, Wonambi, Barinasuchus, Cotylorhynchus, Eryon e Dimorphodon **do UP2**:
  o código existe no mod, mas essas espécies não estão registradas na versão 1.4.3, então
  não aparecem no jogo.

Para incluir mais uma espécie, basta acrescentar uma linha na tabela de `Species.java`.

## 5. Configuração

Arquivo `config/dinobreeding-common.toml` (criado na primeira execução):

| Opção | Padrão | O que faz |
|---|---|---|
| `enabled` | `true` | Liga/desliga o addon inteiro |
| `loveTicks` | `600` | Quanto tempo o dino fica "apaixonado" depois de comer (20 ticks = 1 s) |
| `cooldownTicks` | `6000` | Espera entre acasalamentos (6000 = 5 min) |
| `searchRadius` | `16.0` | Distância máxima para achar o parceiro, em blocos |
| `friendlyOrSneakOnly` | `true` | `true`: dinos hostis só com SHIFT. `false`: clique normal sempre |
| `requireFullHealth` | `true` | Dino ferido só é curado, não acasala |
| `babiesInheritOwner` | `true` | Filhote herda o dono domesticado |
| `disabledSpecies` | `[]` | Ex.: `["unusualprehistory:rex", "unusual_prehistory:carnotaurus"]` |

## 6. Como funciona (resumo técnico)

O addon **não depende das classes** dos dois mods: acha as entidades pelo registro
(`unusualprehistory:rex`, `unusual_prehistory:carnotaurus`...) e usa só a API do Minecraft.
Por isso não quebra se os mods atualizarem, desde que os IDs continuem os mesmos.

- `DinoEvents`: coloca o objetivo de acasalamento em cada dino ao entrar no mundo e trata
  o clique com a comida.
- `DinoMateGoal`: faz os dois se procurarem e se encontrarem.
- `Breeding`: cria o filhote, herda variante e dono, aplica cooldown, partículas e XP.
- `Species`: tabela de espécies, filhotes e comidas.

Usa um estado de "amor" próprio em vez do `Animal#setInLove` do jogo porque vários dinos e
filhotes do UP1 não são `Animal` (o Dunkleosteus é `WaterAnimal`, o Baby Brachi é
`PathfinderMob`), e porque o UP2 desliga `canMate`/`canFallInLove` na classe base.
