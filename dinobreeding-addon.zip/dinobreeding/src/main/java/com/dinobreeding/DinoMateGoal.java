package com.dinobreeding;

import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Equivalente ao BreedGoal do Minecraft, mas para qualquer Mob (nao so Animal)
 * e sem depender de canMate()/canFallInLove(), que os mods desligam em varias especies.
 */
public class DinoMateGoal extends Goal {
    /** Maximo de ticks de goal (cerca de 2x em ticks reais) tentando alcancar o parceiro. */
    private static final int MAX_CHASE = 300;
    /** Minimo de ticks de goal "namorando" antes de acasalar. */
    private static final int MIN_COURTSHIP = 20;

    private final Mob mob;
    private final double speed;
    @Nullable
    private Mob partner;
    private int timer;

    public DinoMateGoal(Mob mob, double speed) {
        this.mob = mob;
        this.speed = speed;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!(this.mob.level() instanceof ServerLevel) || !Breeding.isInLove(this.mob)) {
            return false;
        }
        this.partner = this.findPartner();
        return this.partner != null;
    }

    @Override
    public boolean canContinueToUse() {
        return this.partner != null
                && this.partner.isAlive()
                && Breeding.isInLove(this.partner)
                && Breeding.isInLove(this.mob)
                && this.timer < MAX_CHASE;
    }

    @Override
    public void stop() {
        this.partner = null;
        this.timer = 0;
    }

    @Override
    public void tick() {
        if (this.partner == null || !(this.mob.level() instanceof ServerLevel level)) {
            return;
        }
        this.mob.getLookControl().setLookAt(this.partner, 10.0F, (float) this.mob.getMaxHeadXRot());
        this.mob.getNavigation().moveTo(this.partner, this.speed);
        this.timer++;

        if (this.timer >= MIN_COURTSHIP && this.mob.distanceToSqr(this.partner) <= this.mateDistanceSqr()) {
            Breeding.breed(level, this.mob, this.partner);
        }
    }

    /** Dinos grandes nunca chegam a 3 blocos de distancia do outro, entao a distancia depende do tamanho. */
    private double mateDistanceSqr() {
        double reach = (this.mob.getBbWidth() + this.partner.getBbWidth()) * 0.75D + 1.5D;
        return Math.max(9.0D, reach * reach);
    }

    @Nullable
    private Mob findPartner() {
        double radius = DinoConfig.SEARCH_RADIUS.get();
        List<? extends Mob> candidates = this.mob.level().getEntitiesOfClass(
                this.mob.getClass(),
                this.mob.getBoundingBox().inflate(radius),
                other -> Breeding.isValidPartner(this.mob, other));

        Mob nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (Mob candidate : candidates) {
            double distance = this.mob.distanceToSqr(candidate);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }
}
