package com.dinobreeding;

import com.mojang.logging.LogUtils;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

/**
 * Uma especie que pode se reproduzir.
 *
 * @param id         id de registro do adulto (ex.: unusualprehistory:rex)
 * @param babyType   tipo de entidade do filhote, quando o mod usa uma entidade separada para ele
 *                   (ex.: Baby Rex). null = o filhote e o proprio adulto nascendo pequeno (bebe do Minecraft).
 * @param diets      dietas aceitas como comida de acasalamento
 * @param foodTags   tags de itens extras aceitas (comidas proprias dos mods)
 * @param modFood    true = tambem aceita o que o proprio mod ja considera comida (Animal#isFood)
 * @param peaceful   true = especie pacifica: clicar com a comida ja inicia o acasalamento (sem SHIFT)
 */
public record Species(ResourceLocation id,
                      @Nullable EntityType<?> babyType,
                      Set<Diet> diets,
                      List<TagKey<Item>> foodTags,
                      boolean modFood,
                      boolean peaceful) {

    private static final Logger LOGGER = LogUtils.getLogger();

    private static final String UP1 = "unusualprehistory";
    private static final String UP2 = "unusual_prehistory";
    // Addons do UP
    private static final String MM = "marvelous_menagerie";
    private static final String PP = "peculiarprimordials";
    private static final String SP = "similar_prehistory";
    private static final String WW = "weirdandwonderful";

    private record Def(String mod, String id, @Nullable String baby, boolean modFood, boolean peaceful,
                       @Nullable String foodTag, Diet[] diets) {
    }

    private static Def def(String mod, String id, @Nullable String baby, boolean modFood, boolean peaceful,
                           @Nullable String foodTag, Diet... diets) {
        return new Def(mod, id, baby, modFood, peaceful, foodTag, diets);
    }

    /**
     * Tabela de especies. Para adicionar uma especie nova, basta incluir uma linha aqui.
     * Entradas de mods que nao estao instalados sao ignoradas automaticamente.
     */
    private static final List<Def> DEFS = List.of(
            // ---------- Unusual Prehistory 1: filhote e uma entidade separada ----------
            def(UP1, "rex", "baby_rex", false, false, null, Diet.MEAT),
            def(UP1, "brachi", "baby_brachi", false, true, null, Diet.PLANTS),
            def(UP1, "mammoth", "baby_mammoth", false, true, null, Diet.PLANTS),
            def(UP1, "smilodon", "baby_smilodon", false, false, null, Diet.MEAT),
            def(UP1, "megatherium", "baby_megatherium", false, true, null, Diet.PLANTS),
            def(UP1, "megalania", "baby_megalania", false, false, null, Diet.MEAT),
            def(UP1, "paraceratherium", "baby_paracer", false, true, null, Diet.PLANTS),
            def(UP1, "gigantopithicus", "baby_giganto", false, false, null, Diet.PLANTS),
            def(UP1, "barinasuchus", "baby_barina", true, false, UP1 + ":hwacha_food", Diet.MEAT, Diet.FISH),
            // O registro do mod escreve "baby_palaophis" (sem o segundo 'e'); e assim mesmo.
            def(UP1, "palaeophis", "baby_palaophis", false, false, null, Diet.MEAT, Diet.FISH),
            def(UP1, "dunk", "baby_dunk", false, false, null, Diet.FISH),
            def(UP1, "beelz", "beelz_tadpole", true, false, null),

            // ---------- Unusual Prehistory 1: filhote = o proprio adulto pequeno ----------
            def(UP1, "majunga", null, true, false, UP1 + ":majunga_food", Diet.MEAT),
            def(UP1, "trike", null, true, false, UP1 + ":trike_food", Diet.PLANTS),
            def(UP1, "veloci", null, false, false, null, Diet.MEAT),
            def(UP1, "pachy", null, true, false, UP1 + ":pachy_food", Diet.PLANTS),
            def(UP1, "coty", null, false, true, null, Diet.PLANTS),
            def(UP1, "kentrosaurus", null, false, true, UP1 + ":kentro_food", Diet.PLANTS),
            def(UP1, "antarctopelta", null, false, true, null, Diet.PLANTS),
            def(UP1, "hwachavenator", null, false, false, UP1 + ":hwacha_food", Diet.MEAT, Diet.FISH),
            def(UP1, "austroraptor", null, false, false, null, Diet.MEAT, Diet.FISH),
            def(UP1, "ulughbegsaurus", null, true, false, null, Diet.MEAT),
            def(UP1, "talpanas", null, false, false, null, Diet.PLANTS),

            // ---------- Unusual Prehistory 2: filhote = o proprio adulto pequeno ----------
            // (Talpanas e Unicorn ja se reproduzem sozinhos no UP2, por isso nao estao aqui.)
            // A comida vem do proprio mod (Animal#isFood), que ja tem uma tag de itens por especie.
            def(UP2, "carnotaurus", null, true, false, null),
            def(UP2, "dromaeosaurus", null, true, false, null),
            def(UP2, "kentrosaurus", null, true, false, null),
            def(UP2, "majungasaurus", null, true, false, null),
            def(UP2, "megalania", null, true, false, null),
            def(UP2, "brachiosaurus", null, true, false, null),
            def(UP2, "kaprosuchus", null, true, false, null),
            def(UP2, "leptictidium", null, true, false, null),
            def(UP2, "lystrosaurus", null, true, false, null),
            def(UP2, "pachycephalosaurus", null, true, false, null),
            def(UP2, "praepusa", null, true, false, null),
            def(UP2, "ulughbegsaurus", null, true, false, null),
            def(UP2, "desmatosuchus", null, true, false, null),
            def(UP2, "psilopterus", null, true, false, null),
            def(UP2, "metriorhynchus", null, true, false, null),
            def(UP2, "mosasaurus", null, true, false, null),
            def(UP2, "aegirocassis", null, true, false, null),
            def(UP2, "dunkleosteus", null, true, false, null),
            def(UP2, "hibbertopterus", null, true, false, null),

            // ---------- Addons ----------
            // Marvelous Menagerie (addon do UP1)
            def(MM, "thylacine", null, true, false, null, Diet.MEAT),
            def(MM, "dodo", null, true, true, null, Diet.PLANTS),
            def(MM, "elephant_bird", null, true, true, null, Diet.PLANTS),
            def(MM, "anomalocaris", "baby_anomalocaris", false, false, null, Diet.FISH, Diet.MEAT),
            def(MM, "ophthalmo", "baby_ophthalmo", true, false, null, Diet.FISH),
            def(MM, "steller_sea_cow", "baby_steller_sea_cow", false, true, null, Diet.PLANTS),
            // Peculiar Primordials (a comida vem do proprio mod)
            def(PP, "giganhinga", null, true, false, null),
            def(PP, "neilpeartia", null, true, false, null),
            // Similar Prehistory (so o Latenivenatrix; os outros ja se reproduzem sozinhos)
            def(SP, "latenivenatrix", "latenivenatrix_baby", false, false, null, Diet.MEAT),
            // Weird and Wonderful
            def(WW, "neovenator", null, false, false, null, Diet.MEAT),
            def(WW, "suzhousaurus", null, false, true, null, Diet.PLANTS),
            def(WW, "proapteryx", null, false, true, null, Diet.PLANTS),
            def(WW, "palaeoisipus", null, false, false, null, Diet.MEAT, Diet.FISH)
    );


    /** Tabela embutida + linhas da opcao extraSpecies da config. */
    private static List<Def> allDefs() {
        List<Def> defs = new ArrayList<>(DEFS);
        for (String line : DinoConfig.EXTRA_SPECIES.get()) {
            Def extra = parseExtra(line);
            if (extra == null) {
                LOGGER.warn("[dinobreeding] linha invalida em extraSpecies (ignorada): {}", line);
            } else {
                defs.add(extra);
            }
        }
        return defs;
    }

    /** Formato: "mod:entidade|filhote ou -|dietas (meat,fish,plants) ou -|pacifico (true/false)|comida do mod (true/false)". */
    @Nullable
    private static Def parseExtra(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length < 5) {
            return null;
        }
        ResourceLocation id = ResourceLocation.tryParse(p[0].trim());
        if (id == null) {
            return null;
        }
        String baby = p[1].trim();
        if (baby.isEmpty() || baby.equals("-")) {
            baby = null;
        }
        List<Diet> diets = new ArrayList<>();
        for (String d : p[2].split(",")) {
            String key = d.trim().toUpperCase(java.util.Locale.ROOT);
            if (key.isEmpty() || key.equals("-")) {
                continue;
            }
            try {
                diets.add(Diet.valueOf(key));
            } catch (IllegalArgumentException e) {
                return null;
            }
        }
        boolean peaceful = Boolean.parseBoolean(p[3].trim());
        boolean modFood = Boolean.parseBoolean(p[4].trim());
        return new Def(id.getNamespace(), id.getPath(), baby, modFood, peaceful, null, diets.toArray(new Diet[0]));
    }

    private static volatile Map<EntityType<?>, Species> map;

    /** Retorna a especie correspondente ao tipo de entidade, ou null se nao participa. */
    @Nullable
    public static Species of(EntityType<?> type) {
        return map().get(type);
    }

    private static Map<EntityType<?>, Species> map() {
        Map<EntityType<?>, Species> m = map;
        if (m == null) {
            synchronized (Species.class) {
                m = map;
                if (m == null) {
                    m = build();
                    map = m;
                }
            }
        }
        return m;
    }

    private static Map<EntityType<?>, Species> build() {
        Map<EntityType<?>, Species> result = new HashMap<>();
        List<String> missing = new ArrayList<>();
        for (Def d : allDefs()) {
            ResourceLocation adultId = new ResourceLocation(d.mod(), d.id());
            if (!ForgeRegistries.ENTITY_TYPES.containsKey(adultId)) {
                missing.add(adultId.toString());
                continue; // mod nao instalado (ou versao sem essa entidade)
            }
            EntityType<?> adult = ForgeRegistries.ENTITY_TYPES.getValue(adultId);

            EntityType<?> baby = null;
            if (d.baby() != null) {
                ResourceLocation babyId = new ResourceLocation(d.mod(), d.baby());
                if (ForgeRegistries.ENTITY_TYPES.containsKey(babyId)) {
                    baby = ForgeRegistries.ENTITY_TYPES.getValue(babyId);
                } else {
                    LOGGER.warn("[dinobreeding] filhote {} nao existe; {} vai usar o adulto pequeno.", babyId, adultId);
                }
                // Se o filhote nao existir nessa versao, cai no comportamento "adulto pequeno".
            }

            Set<Diet> diets = EnumSet.noneOf(Diet.class);
            for (Diet diet : d.diets()) {
                diets.add(diet);
            }

            List<TagKey<Item>> tags = new ArrayList<>();
            if (d.foodTag() != null) {
                tags.add(TagKey.create(Registries.ITEM, new ResourceLocation(d.foodTag())));
            }

            result.put(adult, new Species(adultId, baby, diets, List.copyOf(tags), d.modFood(), d.peaceful()));
        }
        LOGGER.info("[dinobreeding] {} especies registradas para reproducao.", result.size());
        if (!missing.isEmpty()) {
            LOGGER.info("[dinobreeding] Entidades nao encontradas (mod ausente ou id diferente): {}", missing);
        }
        return result;
    }

    /** Respeita o interruptor geral e a lista de especies desativadas da config. */
    public boolean enabled() {
        return DinoConfig.ENABLED.get() && !DinoConfig.DISABLED_SPECIES.get().contains(this.id.toString());
    }

    /** O item serve como comida de acasalamento para esta especie? */
    public boolean isBreedingFood(Mob mob, ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        for (Diet diet : this.diets) {
            if (diet.matches(stack)) {
                return true;
            }
        }
        for (TagKey<Item> tag : this.foodTags) {
            if (stack.is(tag)) {
                return true;
            }
        }
        return this.modFood && mob instanceof Animal animal && animal.isFood(stack);
    }
}
