package com.dinobreeding;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DinoBreeding.MODID)
public final class DinoEvents {
    private DinoEvents() {
    }

    /** Todo dino de uma especie suportada ganha o goal de acasalamento ao entrar no mundo. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || !(event.getEntity() instanceof Mob mob)) {
            return;
        }
        Species species = Species.of(mob.getType());
        if (species == null || !species.enabled()) {
            return;
        }
        for (WrappedGoal wrapped : mob.goalSelector.getAvailableGoals()) {
            if (wrapped.getGoal() instanceof DinoMateGoal) {
                return; // ja tem
            }
        }
        mob.goalSelector.addGoal(3, new DinoMateGoal(mob, 1.0D));
    }

    /** Desconta o tempo de amor e de cooldown (a cada 10 ticks, so para as especies do addon). */
    @SubscribeEvent
    public static void onTick(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof Mob mob) || mob.tickCount % 10 != 0) {
            return;
        }
        if (!(mob.level() instanceof ServerLevel level) || Species.of(mob.getType()) == null) {
            return;
        }
        Breeding.tickTimers(level, mob);
    }

    /**
     * Clique direito com a comida certa. Prioridade ALTA para rodar antes do mod original,
     * mas so intercepta quando o dino esta saudavel e "amigavel" (ou o jogador esta agachado),
     * entao curar/pacificar/domesticar continuam funcionando como antes.
     */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Mob mob)) {
            return;
        }
        Species species = Species.of(mob.getType());
        if (species == null || !species.enabled()) {
            return;
        }

        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        if (!species.isBreedingFood(mob, stack)) {
            return;
        }

        boolean clientSide = mob.level().isClientSide();
        if (!Breeding.canBeFed(mob, species, player, !clientSide)) {
            return;
        }

        // Cancela o clique para o mod original nao tratar a mesma comida de novo.
        event.setCancellationResult(InteractionResult.sidedSuccess(clientSide));
        event.setCanceled(true);
        if (clientSide) {
            return;
        }

        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        Breeding.setLove(mob, DinoConfig.LOVE_TICKS.get());
        mob.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
    }
}
