package com.dinobreeding;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;

/**
 * Chamadas por reflexao a metodos publicos DOS PROPRIOS MODS (getVariant, isPacified...).
 * Esses nomes nao sao ofuscados, entao funcionam em producao. Se o metodo nao existir
 * (versao diferente do mod), retorna null e o addon simplesmente ignora aquele detalhe.
 *
 * Nunca use esta classe para metodos do Minecraft: la os nomes mudam em producao.
 */
final class Reflect {
    private static final Map<String, Optional<Method>> CACHE = new ConcurrentHashMap<>();

    private Reflect() {
    }

    @Nullable
    private static Method find(Class<?> type, String name, Class<?>... params) {
        String key = type.getName() + "#" + name + Arrays.toString(params);
        return CACHE.computeIfAbsent(key, k -> {
            try {
                return Optional.of(type.getMethod(name, params));
            } catch (ReflectiveOperationException | RuntimeException e) {
                return Optional.<Method>empty();
            }
        }).orElse(null);
    }

    @Nullable
    static Boolean bool(Object target, String name) {
        Method m = find(target.getClass(), name);
        if (m == null || m.getReturnType() != boolean.class) {
            return null;
        }
        try {
            return (Boolean) m.invoke(target);
        } catch (ReflectiveOperationException | RuntimeException e) {
            return null;
        }
    }

    @Nullable
    static Integer integer(Object target, String name) {
        Method m = find(target.getClass(), name);
        if (m == null || m.getReturnType() != int.class) {
            return null;
        }
        try {
            return (Integer) m.invoke(target);
        } catch (ReflectiveOperationException | RuntimeException e) {
            return null;
        }
    }

    static boolean setInt(Object target, String name, int value) {
        Method m = find(target.getClass(), name, int.class);
        if (m == null) {
            return false;
        }
        try {
            m.invoke(target, value);
            return true;
        } catch (ReflectiveOperationException | RuntimeException e) {
            return false;
        }
    }
}
