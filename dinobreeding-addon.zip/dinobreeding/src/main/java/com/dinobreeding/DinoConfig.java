package com.dinobreeding;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

/** Arquivo gerado em config/dinobreeding-common.toml. */
public final class DinoConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue LOVE_TICKS;
    public static final ForgeConfigSpec.IntValue COOLDOWN_TICKS;
    public static final ForgeConfigSpec.DoubleValue SEARCH_RADIUS;
    public static final ForgeConfigSpec.BooleanValue FRIENDLY_OR_SNEAK;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_FULL_HEALTH;
    public static final ForgeConfigSpec.BooleanValue INHERIT_OWNER;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_SPECIES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("breeding");

        ENABLED = b
                .comment("Liga/desliga o addon inteiro.")
                .define("enabled", true);

        LOVE_TICKS = b
                .comment("Quanto tempo (em ticks, 20 = 1 segundo) o dino fica 'apaixonado' depois de comer.",
                        "Nesse periodo ele procura outro dino da mesma especie tambem apaixonado.")
                .defineInRange("loveTicks", 600, 20, 72000);

        COOLDOWN_TICKS = b
                .comment("Tempo (em ticks) que os pais esperam antes de poderem acasalar de novo.",
                        "6000 = 5 minutos, igual aos animais do jogo padrao.")
                .defineInRange("cooldownTicks", 6000, 0, 1728000);

        SEARCH_RADIUS = b
                .comment("Distancia maxima (em blocos) em que um dino procura o parceiro.")
                .defineInRange("searchRadius", 16.0D, 4.0D, 64.0D);

        FRIENDLY_OR_SNEAK = b
                .comment("true: clicar com a comida so inicia o acasalamento se o dino for 'amigavel'",
                        "(domesticado, pacificado, ou uma especie pacifica). Segurando SHIFT, funciona em qualquer dino.",
                        "Isso evita atrapalhar o jeito original dos mods de pacificar/domesticar com comida.",
                        "false: qualquer clique com a comida correta (e vida cheia) inicia o acasalamento.")
                .define("friendlyOrSneakOnly", true);

        REQUIRE_FULL_HEALTH = b
                .comment("true: o dino so aceita a comida de acasalamento com a vida cheia.",
                        "Se estiver ferido, a comida continua curando, como nos mods originais.")
                .define("requireFullHealth", true);

        INHERIT_OWNER = b
                .comment("true: se um dos pais for domesticado, o filhote nasce domesticado pelo mesmo dono",
                        "(quando o tipo de filhote permite domesticacao).")
                .define("babiesInheritOwner", true);

        DISABLED_SPECIES = b
                .comment("Lista de especies que NAO devem se reproduzir. Exemplo:",
                        "disabledSpecies = [\"unusualprehistory:rex\", \"unusual_prehistory:carnotaurus\"]")
                .defineListAllowEmpty("disabledSpecies", List.of(), o -> o instanceof String);

        b.pop();

        SPEC = b.build();
    }

    private DinoConfig() {
    }
}
