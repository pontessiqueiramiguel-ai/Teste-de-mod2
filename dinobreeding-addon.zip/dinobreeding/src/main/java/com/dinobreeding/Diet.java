package com.dinobreeding;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Tipos de dieta. Cada um corresponde a uma tag de itens em
 * data/dinobreeding/tags/items/food/ -- da para editar via datapack.
 */
public enum Diet {
    MEAT("food/meat"),
    FISH("food/fish"),
    PLANTS("food/plants");

    private final TagKey<Item> tag;

    Diet(String path) {
        this.tag = TagKey.create(Registries.ITEM, new ResourceLocation(DinoBreeding.MODID, path));
    }

    public boolean matches(ItemStack stack) {
        return stack.is(this.tag);
    }
}
