package com.dinobreeding;

import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;

/**
 * Logica de reproducao. Usa um estado de "amor" proprio (guardado nos dados persistentes
 * da entidade) em vez do sistema de amor do Minecraft, porque varios filhotes/adultos dos
 * mods nao sao Animal do Minecraft (ex.: o Dunkleosteus e um WaterAnimal).
 */
public final class Breeding {
    private static final String LOVE = "dinobreeding_love";
    private static final String COOLDOWN = "dinobreeding_cooldown";

    private Breeding() {
    }

    // ------------------------------------------------------------------ estado

    public static boolean isInLove(Mob mob) {
        return mob.getPersistentData().getInt(LOVE) > 0;
    }

    public static void setLove(Mob mob, int ticks) {
        mob.getPersistentData().putInt(LOVE, ticks);
    }

    private static void clearLove(Mob mob) {
        mob.getPersistentData().remove(LOVE);
    }

    private static int cooldown(Mob mob) {
        return mob.getPersistentData().getInt(COOLDOWN);
    }

    private static void setCooldown(Mob mob, int ticks) {
        mob.getPersistentData().putInt(COOLDOWN, ticks);
    }

    /** Chamado a cada 10 ticks para dinos que participam: desconta amor e cooldown. */
    static void tickTimers(ServerLevel level, Mob mob) {
        CompoundTag data = mob.getPersistentData();

        int love = data.getInt(LOVE);
        if (love > 0) {
            data.putInt(LOVE, Math.max(0, love - 10));
            level.sendParticles(ParticleTypes.HEART, mob.getRandomX(1.0D), mob.getRandomY() + 0.5D,
                    mob.getRandomZ(1.0D), 1, 0.0D, 0.0D, 0.0D, 0.02D);
        }

        int cd = data.getInt(COOLDOWN);
        if (cd > 0) {
            data.putInt(COOLDOWN, Math.max(0, cd - 10));
        }
    }

    // ------------------------------------------------------------- alimentacao

    /**
     * O dino pode aceitar comida de acasalamento agora?
     *
     * @param authoritative true no servidor (confere amor/cooldown, que so existem la);
     *                      false no cliente (so confere o que o cliente sabe).
     */
    static boolean canBeFed(Mob mob, Species species, Player player, boolean authoritative) {
        if (!mob.isAlive()) {
            return false;
        }
        if (mob instanceof AgeableMob ageable && ageable.isBaby()) {
            return false;
        }
        if (DinoConfig.REQUIRE_FULL_HEALTH.get() && mob.getHealth() < mob.getMaxHealth()) {
            return false; // ferido: deixa o mod original curar com a comida
        }
        if (authoritative && (isInLove(mob) || cooldown(mob) > 0)) {
            return false;
        }
        if (DinoConfig.FRIENDLY_OR_SNEAK.get() && !player.isShiftKeyDown() && !isFriendly(mob, species)) {
            return false;
        }
        return true;
    }

    /**
     * Dino "amigavel": domesticado, pacificado, ou de uma especie pacifica.
     * Os metodos canPacify/isPacified (UP2) e getPassiveTicks (UP1) sao dos proprios mods.
     */
    static boolean isFriendly(Mob mob, Species species) {
        if (species.peaceful()) {
            return true;
        }
        if (mob instanceof TamableAnimal tamable && tamable.isTame()) {
            return true;
        }
        Boolean canPacify = Reflect.bool(mob, "canPacify");
        if (canPacify != null && !canPacify) {
            return true; // especie do UP2 que nunca fica hostil
        }
        Boolean pacified = Reflect.bool(mob, "isPacified");
        if (pacified != null && pacified) {
            return true;
        }
        Integer passiveTicks = Reflect.integer(mob, "getPassiveTicks");
        return passiveTicks != null && passiveTicks > 0;
    }

    // ------------------------------------------------------------ acasalamento

    /** Procura-se o parceiro: mesmo tipo, vivo, adulto, tambem apaixonado. */
    static boolean isValidPartner(Mob self, Mob other) {
        return other != self
                && other.isAlive()
                && other.getType() == self.getType()
                && isInLove(other)
                && !(other instanceof AgeableMob ageable && ageable.isBaby());
    }

    /** Faz o nascimento: cria o filhote, reseta amor/cooldown dos pais, particulas e XP. */
    static void breed(ServerLevel level, Mob a, Mob b) {
        Species species = Species.of(a.getType());

        if (species != null) {
            Mob child = createChild(level, species, a, b);
            if (child != null) {
                child.moveTo(a.getX(), a.getY(), a.getZ(), 0.0F, 0.0F);
                if (species.babyType() == null && child instanceof AgeableMob ageableChild) {
                    ageableChild.setBaby(true);
                }
                copyVariant(a, b, child);
                inheritOwner(a, b, child);
                child.setPersistenceRequired();
                level.addFreshEntityWithPassengers(child);
            }
        }

        int cooldown = DinoConfig.COOLDOWN_TICKS.get();
        for (Mob parent : new Mob[] {a, b}) {
            clearLove(parent);
            setCooldown(parent, cooldown);
            level.sendParticles(ParticleTypes.HEART, parent.getRandomX(1.0D), parent.getRandomY() + 0.5D,
                    parent.getRandomZ(1.0D), 7, 0.5D, 0.5D, 0.5D, 0.02D);
        }

        if (level.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            level.addFreshEntity(new ExperienceOrb(level, a.getX(), a.getY(), a.getZ(), a.getRandom().nextInt(7) + 1));
        }
    }

    @Nullable
    private static Mob createChild(ServerLevel level, Species species, Mob a, Mob b) {
        // 1) Mods que usam uma entidade separada para o filhote (ex.: Baby Rex do UP1).
        if (species.babyType() != null) {
            Entity baby = species.babyType().create(level);
            return baby instanceof Mob mob ? mob : null;
        }

        // 2) Deixa o proprio mod criar o filhote, se ele ja sabe como (UP2 e parte do UP1).
        if (a instanceof AgeableMob ageableA && b instanceof AgeableMob ageableB) {
            try {
                AgeableMob offspring = ageableA.getBreedOffspring(level, ageableB);
                if (offspring != null) {
                    return offspring;
                }
            } catch (RuntimeException ignored) {
                // cai para a criacao direta abaixo
            }
        }

        // 3) Cria outro do mesmo tipo; quem chama marca como bebe.
        Entity same = a.getType().create(level);
        return same instanceof Mob mob ? mob : null;
    }

    /** Filhote herda a variante (cor/subtipo) de um dos pais, sorteado. */
    private static void copyVariant(Mob a, Mob b, Mob child) {
        Mob source = a.getRandom().nextBoolean() ? a : b;
        Integer variant = Reflect.integer(source, "getVariant");
        if (variant != null) {
            Reflect.setInt(child, "setVariant", variant);
        }
    }

    private static void inheritOwner(Mob a, Mob b, Mob child) {
        if (!DinoConfig.INHERIT_OWNER.get() || !(child instanceof TamableAnimal childTamable)) {
            return;
        }
        TamableAnimal owner = null;
        if (a instanceof TamableAnimal tamableA && tamableA.isTame() && tamableA.getOwnerUUID() != null) {
            owner = tamableA;
        } else if (b instanceof TamableAnimal tamableB && tamableB.isTame() && tamableB.getOwnerUUID() != null) {
            owner = tamableB;
        }
        if (owner != null) {
            childTamable.setTame(true);
            childTamable.setOwnerUUID(owner.getOwnerUUID());
        }
    }
}
