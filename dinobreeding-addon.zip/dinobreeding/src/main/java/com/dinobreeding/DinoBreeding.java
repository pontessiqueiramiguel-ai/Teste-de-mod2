package com.dinobreeding;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/**
 * Addon que adiciona reproducao aos dinossauros do Unusual Prehistory 1 e 2.
 *
 * Nao depende das classes dos dois mods em tempo de compilacao: as entidades sao
 * encontradas pelo registro (ResourceLocation) e usadas pela API normal do Minecraft.
 */
@Mod(DinoBreeding.MODID)
public class DinoBreeding {
    public static final String MODID = "dinobreeding";

    public DinoBreeding() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, DinoConfig.SPEC);
    }
}
